export { default as PageTranslator } from '../PageTranslator';
export { default as TranslatedText } from '../TranslatedText';
export { default as T } from '../T';