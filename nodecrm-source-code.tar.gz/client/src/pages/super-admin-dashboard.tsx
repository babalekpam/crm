import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { 
  Building2, 
  Users, 
  DollarSign, 
  TrendingUp, 
  Shield, 
  Activity,
  AlertTriangle,
  CheckCircle,
  Clock,
  Download,
  Filter,
  RefreshCw,
  Search,
  Eye,
  BarChart3,
  PieChart,
  LineChart
} from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';
import Layout from '@/components/layout';

interface TenantOverview {
  id: string;
  name: string;
  domain: string;
  subscriptionPlan: string;
  status: string;
  billingCycle: string;
  monthlyRevenue: string;
  yearlyRevenue: string;
  userCount: number;
  activeUserCount: number;
  maxUsers: number;
  isActive: boolean;
  createdAt: Date;
  lastActivity: Date;
  currentUsage: {
    storage: number;
    apiCalls: number;
  };
  usageLimits: {
    storage: number;
    apiCalls: number;
  };
  enabledFeatures: string[];
}

interface PlatformMetrics {
  totalTenants: number;
  activeTenants: number;
  totalUsers: number;
  totalMonthlyRevenue: number;
  planDistribution: Record<string, number>;
  averageUsersPerTenant: number;
}

interface AuditLog {
  id: string;
  tenantId: string;
  userId: string;
  action: string;
  resource: string;
  resourceId: string;
  severity: string;
  outcome: string;
  timestamp: Date;
  details: any;
}

interface ComplianceMatrix {
  tenantId: string;
  tenantName: string;
  subscriptionPlan: string;
  subscriptionStatus: string;
  featureCompliance: Array<{
    feature: string;
    enabled: boolean;
    compliant: boolean;
  }>;
  usageCompliance: Array<{
    resource: string;
    current: number;
    limit: number;
    usage: number;
    compliant: boolean;
  }>;
  overallCompliance: {
    features: boolean;
    usage: boolean;
    score: number;
  };
}

interface UserRegistration {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  company: string;
  registrationDate: Date;
  status: string;
  subscriptionPlan: string;
  lastLogin: Date;
  totalLogins: number;
  verificationStatus: string;
  source: string;
  tenantId: string;
}

interface RegistrationStats {
  total: number;
  active: number;
  trial: number;
  inactive: number;
  verified: number;
  pending: number;
  planDistribution: Record<string, number>;
  sourceDistribution: Record<string, number>;
}

export default function SuperAdminDashboard() {
  const [selectedTenant, setSelectedTenant] = useState<string>('all');
  const [reportType, setReportType] = useState<string>('summary');
  const [dateRange, setDateRange] = useState({
    start: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    end: new Date().toISOString().split('T')[0]
  });
  const [logFilters, setLogFilters] = useState({
    tenantId: '',
    action: '',
    resource: '',
    severity: ''
  });

  const queryClient = useQueryClient();

  // Tenant management functions
  const handleManualActivation = async (userId: string, email: string) => {
    try {
      const response = await apiRequest('POST', '/api/admin/activate-user', {
        userId,
        email
      });
      
      if (response.ok) {
        console.log('User activated successfully');
        refetchRegistrations();
      }
    } catch (error) {
      console.error('Failed to activate user:', error);
    }
  };

  const handleActivateTenant = async (tenantId: string, email: string) => {
    try {
      const response = await apiRequest('POST', '/api/admin/tenant/activate', {
        tenantId,
        email
      });
      
      if (response.ok) {
        console.log('Tenant activated successfully');
        refetchRegistrations();
      }
    } catch (error) {
      console.error('Failed to activate tenant:', error);
    }
  };

  const handleDeactivateTenant = async (tenantId: string, email: string) => {
    try {
      const response = await apiRequest('POST', '/api/admin/tenant/deactivate', {
        tenantId,
        email
      });
      
      if (response.ok) {
        console.log('Tenant deactivated successfully');
        refetchRegistrations();
      }
    } catch (error) {
      console.error('Failed to deactivate tenant:', error);
    }
  };

  // DISABLED: Fetch global tenant overview - causing authentication errors that block UI
  const tenantData = { tenants: [] };
  const tenantsLoading = false;
  const refetchTenants = () => {};

  // Fetch audit logs
  const { data: auditData, isLoading: auditLoading, refetch: refetchAudit } = useQuery({
    queryKey: ['/api/superadmin/logs', logFilters],
    queryFn: async () => {
      const params = new URLSearchParams();
      Object.entries(logFilters).forEach(([key, value]) => {
        if (value) params.append(key, value);
      });
      
      const response = await fetch(`/api/superadmin/logs?${params}`);
      if (!response.ok) throw new Error('Failed to fetch audit logs');
      return response.json();
    }
  });

  // Fetch compliance matrix
  const { data: complianceData, isLoading: complianceLoading, refetch: refetchCompliance } = useQuery({
    queryKey: ['/api/superadmin/compliance-matrix'],
    queryFn: async () => {
      const response = await fetch('/api/superadmin/compliance-matrix');
      if (!response.ok) throw new Error('Failed to fetch compliance matrix');
      return response.json();
    }
  });

  // Fetch user registrations - FIXED: Use correct endpoint with proper auth
  const { data: registrationData, isLoading: registrationsLoading, refetch: refetchRegistrations } = useQuery({
    queryKey: ['/api/admin/users'],
    queryFn: async () => {
      const response = await fetch('/api/admin/users', {
        credentials: 'include' // Use proper JWT authentication
      });
      if (!response.ok) {
        console.error('Failed to fetch registered users:', response.status);
        throw new Error('Failed to fetch registered users');
      }
      const data = await response.json();
      console.log('✅ FRONTEND: Received registration data:', data);
      console.log('✅ FRONTEND: Total users count:', data.totalUsers);
      console.log('✅ FRONTEND: Users array length:', data.users?.length);
      return data;
    }
  });

  // Fetch platform stats - FIXED: Use correct dashboard endpoint
  const { data: platformData, isLoading: platformLoading, refetch: refetchPlatform } = useQuery({
    queryKey: ['/api/admin/dashboard'],
    queryFn: async () => {
      const response = await fetch('/api/admin/dashboard', {
        credentials: 'include' // Use proper JWT authentication
      });
      if (!response.ok) {
        console.error('Failed to fetch platform stats:', response.status);
        throw new Error('Failed to fetch platform stats');
      }
      const data = await response.json();
      console.log('✅ FIXED: Fetched real platform stats:', data);
      return data;
    }
  });

  // Generate cross-tenant report
  const generateReportMutation = useMutation({
    mutationFn: async (reportConfig: any) => {
      const response = await fetch('/api/superadmin/reports', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(reportConfig)
      });
      if (!response.ok) throw new Error('Failed to generate report');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/superadmin/reports'] });
    }
  });

  const tenants: TenantOverview[] = tenantData?.tenants || [];
  const platformMetrics: PlatformMetrics = platformData?.stats || {};
  const auditLogs: AuditLog[] = auditData?.logs || [];
  const complianceMatrix: ComplianceMatrix[] = complianceData?.complianceMatrix || {};

  const handleGenerateReport = () => {
    generateReportMutation.mutate({
      reportType,
      dateRange,
      tenantIds: selectedTenant === 'all' ? [] : [selectedTenant],
      includeMetrics: true
    });
  };

  const handleRefreshAll = () => {
    refetchTenants();
    refetchAudit();
    refetchCompliance();
    refetchRegistrations();
    refetchPlatform();
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, "default" | "secondary" | "destructive" | "outline"> = {
      active: "default",
      trial: "secondary",
      suspended: "destructive",
      cancelled: "outline"
    };
    return <Badge variant={variants[status] || "outline"}>{status}</Badge>;
  };

  const getPlanBadge = (plan: string) => {
    const colors: Record<string, string> = {
      starter: "bg-blue-100 text-blue-800",
      professional: "bg-green-100 text-green-800", 
      enterprise: "bg-purple-100 text-purple-800",
      unlimited: "bg-gold-100 text-gold-800"
    };
    return (
      <Badge className={colors[plan] || "bg-gray-100 text-gray-800"}>
        {plan}
      </Badge>
    );
  };

  const getSeverityColor = (severity: string) => {
    const colors: Record<string, string> = {
      info: "text-blue-600",
      warning: "text-yellow-600",
      error: "text-red-600"
    };
    return colors[severity] || "text-gray-600";
  };

  // FIXED: Don't block the entire dashboard for failed tenant data
  // The main admin functionality (users, dashboard) works fine

  return (
    <Layout>
      <div className="p-6 space-y-6">
        {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Super Admin Dashboard</h1>
          <p className="text-muted-foreground">Global platform management and tenant oversight</p>
        </div>
        <div className="flex items-center space-x-2">
          <Button variant="outline" onClick={handleRefreshAll}>
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh All
          </Button>
          <Button variant="outline">
            <Download className="h-4 w-4 mr-2" />
            Export Data
          </Button>
        </div>
      </div>

      {/* Platform Metrics Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Tenants</CardTitle>
            <Building2 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{platformMetrics.totalTenants || 0}</div>
            <p className="text-xs text-muted-foreground">
              {platformMetrics.activeTenants || 0} active
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Users</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{registrationData?.totalUsers || 0}</div>
            <p className="text-xs text-muted-foreground">
              Avg users per tenant
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Monthly Revenue</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${platformMetrics.totalMonthlyRevenue?.toFixed(2) || '0.00'}</div>
            <p className="text-xs text-muted-foreground">
              <TrendingUp className="h-3 w-3 inline mr-1" />
              +15.2% from last month
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Platform Health</CardTitle>
            <Shield className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">Healthy</div>
            <p className="text-xs text-muted-foreground">
              All systems operational
            </p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="registrations" className="space-y-4">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="registrations">User Registrations</TabsTrigger>
          <TabsTrigger value="tenants">Tenant Overview</TabsTrigger>
          <TabsTrigger value="reports">Cross-Tenant Reports</TabsTrigger>
          <TabsTrigger value="audit">Audit Logs</TabsTrigger>
          <TabsTrigger value="compliance">Compliance Matrix</TabsTrigger>
        </TabsList>

        {/* User Registrations Tab */}
        <TabsContent value="registrations" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Users className="h-5 w-5 mr-2" />
                User Registration Tracking
              </CardTitle>
              <CardDescription>
                Monitor and analyze platform user registrations and activity
              </CardDescription>
            </CardHeader>
            <CardContent>
              {registrationsLoading ? (
                <div className="flex items-center justify-center py-8">
                  <RefreshCw className="h-6 w-6 animate-spin mr-2" />
                  <span>Loading registration data...</span>
                </div>
              ) : (
                <div className="space-y-6">
                  {/* Registration Statistics */}
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    <Card className="bg-blue-50 border-blue-200">
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="text-sm font-medium text-blue-600">Total Registrations</p>
                            <p className="text-2xl font-bold text-blue-800">{registrationData?.totalUsers || 0}</p>
                          </div>
                          <Users className="h-8 w-8 text-blue-500" />
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card className="bg-green-50 border-green-200">
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="text-sm font-medium text-green-600">Active Users</p>
                            <p className="text-2xl font-bold text-green-800">{registrationData?.users?.filter((u: any) => u.isVerified).length || 0}</p>
                          </div>
                          <CheckCircle className="h-8 w-8 text-green-500" />
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card className="bg-yellow-50 border-yellow-200">
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="text-sm font-medium text-yellow-600">Trial Users</p>
                            <p className="text-2xl font-bold text-yellow-800">{registrationData?.users?.filter((u: any) => !u.isVerified).length || 0}</p>
                          </div>
                          <Clock className="h-8 w-8 text-yellow-500" />
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card className="bg-purple-50 border-purple-200">
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="text-sm font-medium text-purple-600">Verified</p>
                            <p className="text-2xl font-bold text-purple-800">{registrationData?.users?.filter((u: any) => u.isVerified).length || 0}</p>
                          </div>
                          <Shield className="h-8 w-8 text-purple-500" />
                        </div>
                      </CardContent>
                    </Card>
                  </div>

                  {/* Registration Analytics */}
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-lg">Subscription Plan Distribution</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-3">
                          {Object.entries(registrationData?.stats?.planDistribution || {}).map(([plan, count]) => (
                            <div key={plan} className="flex items-center justify-between">
                              <div className="flex items-center space-x-2">
                                {getPlanBadge(plan)}
                                <span className="text-sm font-medium capitalize">{plan}</span>
                              </div>
                              <div className="flex items-center space-x-2">
                                <span className="text-sm font-bold">{String(count)}</span>
                                <Progress 
                                  value={(Number(count) / (registrationData?.stats?.total || 1)) * 100} 
                                  className="w-16 h-2"
                                />
                              </div>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardHeader>
                        <CardTitle className="text-lg">Registration Sources</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-3">
                          {Object.entries(registrationData?.stats?.sourceDistribution || {}).map(([source, count]) => (
                            <div key={source} className="flex items-center justify-between">
                              <div className="flex items-center space-x-2">
                                <Badge variant="outline" className="capitalize">
                                  {source.replace('_', ' ')}
                                </Badge>
                              </div>
                              <div className="flex items-center space-x-2">
                                <span className="text-sm font-bold">{String(count)}</span>
                                <Progress 
                                  value={(Number(count) / (registrationData?.stats?.total || 1)) * 100} 
                                  className="w-16 h-2"
                                />
                              </div>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  </div>

                  {/* Detailed User List */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">Recent Registrations</CardTitle>
                      <CardDescription>Latest user registrations with activity details</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="max-h-96 overflow-auto">
                        <div className="space-y-3">
                          {registrationData?.users?.map((registration: any) => (
                            <Card key={registration.id} className="p-4">
                              <div className="flex items-center justify-between">
                                <div className="space-y-1">
                                  <div className="flex items-center space-x-3">
                                    <div className="font-medium text-sm">
                                      {registration.firstName} {registration.lastName}
                                    </div>
                                    <Badge variant={registration.subscriptionStatus === 'active' ? 'default' : 
                                                 registration.subscriptionStatus === 'trial' ? 'secondary' : 'outline'}>
                                      {registration.subscriptionStatus}
                                    </Badge>
                                    {getPlanBadge(registration.selectedPackage)}
                                    <Badge variant={registration.isVerified ? 'default' : 'destructive'}>
                                      {registration.isVerified ? 'verified' : 'pending'}
                                    </Badge>
                                  </div>
                                  <div className="text-sm text-muted-foreground">
                                    {registration.email} • {registration.company}
                                  </div>
                                  <div className="flex items-center space-x-4 text-xs text-muted-foreground">
                                    <span>Registered: {new Date(registration.registeredAt).toLocaleDateString()}</span>
                                    <span>Last login: {registration.lastLogin ? new Date(registration.lastLogin).toLocaleDateString() : 'Never'}</span>
                                    <span>Total logins: {registration.totalLogins || 0}</span>
                                    <span>Source: {registration.source ? registration.source.replace('_', ' ') : 'Direct signup'}</span>
                                  </div>
                                </div>
                                <div className="flex items-center space-x-2">
                                  <Button variant="ghost" size="sm">
                                    <Eye className="h-4 w-4" />
                                  </Button>
                                  {!registration.isVerified && (
                                    <Button 
                                      variant="outline" 
                                      size="sm"
                                      onClick={() => handleManualActivation(registration.id, registration.email)}
                                      className="text-green-600 hover:text-green-700"
                                    >
                                      Activate
                                    </Button>
                                  )}
                                  {registration.subscriptionStatus === 'active' ? (
                                    <Button 
                                      variant="outline" 
                                      size="sm"
                                      onClick={() => handleDeactivateTenant(registration.tenantId, registration.email)}
                                      className="text-red-600 hover:text-red-700"
                                    >
                                      Deactivate
                                    </Button>
                                  ) : (
                                    <Button 
                                      variant="outline" 
                                      size="sm"
                                      onClick={() => handleActivateTenant(registration.tenantId, registration.email)}
                                      className="text-green-600 hover:text-green-700"
                                    >
                                      Reactivate
                                    </Button>
                                  )}
                                </div>
                              </div>
                            </Card>
                          )) || (
                            <div className="text-center py-8 text-muted-foreground">
                              No registration data available
                            </div>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tenant Overview Tab */}
        <TabsContent value="tenants" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Building2 className="h-5 w-5 mr-2" />
                Global Tenant Overview
              </CardTitle>
              <CardDescription>
                Comprehensive view of all platform tenants and their status
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {/* Plan Distribution Chart */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div>
                    <h4 className="text-sm font-medium mb-3">Plan Distribution</h4>
                    <div className="space-y-2">
                      {Object.entries(platformMetrics.planDistribution || {}).map(([plan, count]) => (
                        <div key={plan} className="flex items-center justify-between">
                          <div className="flex items-center">
                            {getPlanBadge(plan)}
                            <span className="ml-2 text-sm">{plan}</span>
                          </div>
                          <span className="text-sm font-medium">{count}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="text-sm font-medium mb-3">Revenue by Plan</h4>
                    <div className="space-y-2">
                      {tenants.map((tenant) => (
                        <div key={tenant.id} className="flex items-center justify-between">
                          <span className="text-sm">{tenant.name}</span>
                          <span className="text-sm font-medium">${tenant.monthlyRevenue}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                <Separator />

                {/* Tenant Details Table */}
                <div className="space-y-3">
                  <h4 className="text-sm font-medium">Tenant Details</h4>
                  <ScrollArea className="h-64">
                    <div className="space-y-3">
                      {tenants.map((tenant) => (
                        <Card key={tenant.id} className="p-4">
                          <div className="flex items-center justify-between">
                            <div className="space-y-1">
                              <div className="flex items-center space-x-2">
                                <h5 className="font-medium">{tenant.name}</h5>
                                {getStatusBadge(tenant.status)}
                                {getPlanBadge(tenant.subscriptionPlan)}
                              </div>
                              <p className="text-sm text-muted-foreground">{tenant.domain}</p>
                              <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                                <span>{tenant.userCount} users</span>
                                <span>${tenant.monthlyRevenue}/mo</span>
                                <span>Created {new Date(tenant.createdAt).toLocaleDateString()}</span>
                              </div>
                            </div>
                            <div className="text-right space-y-1">
                              <div className="flex items-center space-x-2">
                                <Activity className="h-4 w-4" />
                                <span className="text-sm">
                                  {new Date(tenant.lastActivity).toLocaleDateString()}
                                </span>
                              </div>
                              <div className="space-y-1">
                                <div className="text-xs">
                                  Storage: {tenant.currentUsage.storage}/{tenant.usageLimits.storage}MB
                                </div>
                                <Progress 
                                  value={(tenant.currentUsage.storage / tenant.usageLimits.storage) * 100} 
                                  className="h-1"
                                />
                              </div>
                            </div>
                          </div>
                        </Card>
                      ))}
                    </div>
                  </ScrollArea>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Cross-Tenant Reports Tab */}
        <TabsContent value="reports" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <BarChart3 className="h-5 w-5 mr-2" />
                Cross-Tenant Report Generation
              </CardTitle>
              <CardDescription>
                Generate comprehensive reports across all or selected tenants
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-6">
                <div className="space-y-2">
                  <Label htmlFor="reportType">Report Type</Label>
                  <Select value={reportType} onValueChange={setReportType}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select report type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="summary">Platform Summary</SelectItem>
                      <SelectItem value="revenue">Revenue Analysis</SelectItem>
                      <SelectItem value="usage">Usage Analytics</SelectItem>
                      <SelectItem value="growth">Growth Metrics</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="tenant">Tenant Filter</Label>
                  <Select value={selectedTenant} onValueChange={setSelectedTenant}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select tenant" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Tenants</SelectItem>
                      {tenants.map((tenant) => (
                        <SelectItem key={tenant.id} value={tenant.id}>
                          {tenant.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Date Range</Label>
                  <div className="flex space-x-2">
                    <Input
                      type="date"
                      value={dateRange.start}
                      onChange={(e) => setDateRange(prev => ({ ...prev, start: e.target.value }))}
                    />
                    <Input
                      type="date"
                      value={dateRange.end}
                      onChange={(e) => setDateRange(prev => ({ ...prev, end: e.target.value }))}
                    />
                  </div>
                </div>
              </div>

              <Button 
                onClick={handleGenerateReport}
                disabled={generateReportMutation.isPending}
                className="w-full mb-4"
              >
                {generateReportMutation.isPending ? (
                  <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                ) : (
                  <BarChart3 className="h-4 w-4 mr-2" />
                )}
                Generate Report
              </Button>

              {generateReportMutation.isSuccess && (
                <Card className="bg-green-50">
                  <CardContent className="p-4">
                    <div className="flex items-center">
                      <CheckCircle className="h-5 w-5 text-green-600 mr-2" />
                      <span className="font-medium">Report Generated Successfully</span>
                    </div>
                    <p className="text-sm text-muted-foreground mt-1">
                      Your {reportType} report has been generated for the selected time period.
                    </p>
                  </CardContent>
                </Card>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Audit Logs Tab */}
        <TabsContent value="audit" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Activity className="h-5 w-5 mr-2" />
                Platform Audit Log Aggregation
              </CardTitle>
              <CardDescription>
                Comprehensive audit trail across all tenant activities
              </CardDescription>
            </CardHeader>
            <CardContent>
              {/* Audit Filters */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                <Select value={logFilters.tenantId || "all"} onValueChange={(value) => 
                  setLogFilters(prev => ({ ...prev, tenantId: value === "all" ? "" : value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Filter by tenant" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Tenants</SelectItem>
                    {tenants.map((tenant) => (
                      <SelectItem key={tenant.id} value={tenant.id}>
                        {tenant.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Select value={logFilters.action || "all"} onValueChange={(value) => 
                  setLogFilters(prev => ({ ...prev, action: value === "all" ? "" : value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Filter by action" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Actions</SelectItem>
                    <SelectItem value="CREATE">Create</SelectItem>
                    <SelectItem value="UPDATE">Update</SelectItem>
                    <SelectItem value="DELETE">Delete</SelectItem>
                    <SelectItem value="LOGIN">Login</SelectItem>
                    <SelectItem value="LOGOUT">Logout</SelectItem>
                  </SelectContent>
                </Select>

                <Select value={logFilters.resource || "all"} onValueChange={(value) => 
                  setLogFilters(prev => ({ ...prev, resource: value === "all" ? "" : value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Filter by resource" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Resources</SelectItem>
                    <SelectItem value="contacts">Contacts</SelectItem>
                    <SelectItem value="deals">Deals</SelectItem>
                    <SelectItem value="accounts">Accounts</SelectItem>
                    <SelectItem value="authentication">Authentication</SelectItem>
                    <SelectItem value="settings">Settings</SelectItem>
                  </SelectContent>
                </Select>

                <Select value={logFilters.severity || "all"} onValueChange={(value) => 
                  setLogFilters(prev => ({ ...prev, severity: value === "all" ? "" : value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Filter by severity" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Severities</SelectItem>
                    <SelectItem value="info">Info</SelectItem>
                    <SelectItem value="warning">Warning</SelectItem>
                    <SelectItem value="error">Error</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Audit Statistics */}
              {auditData?.statistics && (
                <div className="grid grid-cols-2 gap-4 mb-6">
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm">Actions</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      {Object.entries(auditData.statistics.actions).map(([action, count]) => (
                        <div key={action} className="flex justify-between">
                          <span className="text-sm">{action}</span>
                          <span className="text-sm font-medium">{String(count)}</span>
                        </div>
                      ))}
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm">Severity</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      {Object.entries(auditData.statistics.severity).map(([severity, count]) => (
                        <div key={severity} className="flex justify-between">
                          <span className={`text-sm ${getSeverityColor(severity)}`}>{severity}</span>
                          <span className="text-sm font-medium">{String(count)}</span>
                        </div>
                      ))}
                    </CardContent>
                  </Card>
                </div>
              )}

              {/* Audit Log Entries */}
              <ScrollArea className="h-96">
                <div className="space-y-3">
                  {auditLogs.map((log) => (
                    <Card key={log.id} className="p-4">
                      <div className="flex items-start justify-between">
                        <div className="space-y-1">
                          <div className="flex items-center space-x-2">
                            <Badge variant="outline">{log.action}</Badge>
                            <span className="text-sm">{log.resource}</span>
                            <Badge 
                              variant={log.outcome === 'success' ? 'default' : 'destructive'}
                              className="text-xs"
                            >
                              {log.outcome}
                            </Badge>
                          </div>
                          <p className="text-sm text-muted-foreground">
                            Tenant: {tenants.find(t => t.id === log.tenantId)?.name || log.tenantId}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {log.details.ipAddress} • {new Date(log.timestamp).toLocaleString()}
                          </p>
                        </div>
                        <div className="text-right">
                          <Badge 
                            variant="outline" 
                            className={getSeverityColor(log.severity)}
                          >
                            {log.severity}
                          </Badge>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Compliance Matrix Tab */}
        <TabsContent value="compliance" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Shield className="h-5 w-5 mr-2" />
                Subscription Compliance Matrix
              </CardTitle>
              <CardDescription>
                Monitor feature entitlements and usage limits across all tenants
              </CardDescription>
            </CardHeader>
            <CardContent>
              {/* Compliance Summary */}
              {complianceData?.summary && (
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                  <Card>
                    <CardContent className="p-4">
                      <div className="text-2xl font-bold text-green-600">
                        {complianceData.summary.fullyCompliant}
                      </div>
                      <p className="text-sm text-muted-foreground">Fully Compliant</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-4">
                      <div className="text-2xl font-bold text-red-600">
                        {complianceData.summary.featureViolations}
                      </div>
                      <p className="text-sm text-muted-foreground">Feature Violations</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-4">
                      <div className="text-2xl font-bold text-yellow-600">
                        {complianceData.summary.usageViolations}
                      </div>
                      <p className="text-sm text-muted-foreground">Usage Violations</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-4">
                      <div className="text-2xl font-bold">
                        {complianceData.summary.averageComplianceScore}%
                      </div>
                      <p className="text-sm text-muted-foreground">Avg Compliance</p>
                    </CardContent>
                  </Card>
                </div>
              )}

              {/* Compliance Details */}
              <ScrollArea className="h-96">
                <div className="space-y-4">
                  {Array.isArray(complianceMatrix) && complianceMatrix.map((tenant) => (
                    <Card key={tenant.tenantId} className="p-4">
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <h4 className="font-medium">{tenant.tenantName}</h4>
                            <div className="flex items-center space-x-2 mt-1">
                              {getPlanBadge(tenant.subscriptionPlan)}
                              {getStatusBadge(tenant.subscriptionStatus)}
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="text-2xl font-bold">
                              {tenant.overallCompliance.score}%
                            </div>
                            <p className="text-sm text-muted-foreground">Compliance Score</p>
                          </div>
                        </div>

                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                          {/* Feature Compliance */}
                          <div>
                            <h5 className="text-sm font-medium mb-2">Feature Compliance</h5>
                            <div className="space-y-2">
                              {tenant.featureCompliance.map((feature) => (
                                <div key={feature.feature} className="flex items-center justify-between">
                                  <span className="text-sm">{feature.feature}</span>
                                  <div className="flex items-center space-x-2">
                                    {feature.compliant ? (
                                      <CheckCircle className="h-4 w-4 text-green-600" />
                                    ) : (
                                      <AlertTriangle className="h-4 w-4 text-red-600" />
                                    )}
                                    <Badge variant={feature.enabled ? "default" : "outline"}>
                                      {feature.enabled ? "Enabled" : "Disabled"}
                                    </Badge>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>

                          {/* Usage Compliance */}
                          <div>
                            <h5 className="text-sm font-medium mb-2">Usage Compliance</h5>
                            <div className="space-y-3">
                              {tenant.usageCompliance.map((usage) => (
                                <div key={usage.resource} className="space-y-1">
                                  <div className="flex items-center justify-between">
                                    <span className="text-sm">{usage.resource}</span>
                                    <span className="text-sm">
                                      {usage.current}/{usage.limit}
                                    </span>
                                  </div>
                                  <Progress 
                                    value={usage.usage} 
                                    className={`h-2 ${usage.compliant ? '' : 'bg-red-100'}`}
                                  />
                                  <div className="flex justify-between text-xs text-muted-foreground">
                                    <span>{usage.usage.toFixed(1)}% used</span>
                                    {usage.compliant ? (
                                      <span className="text-green-600">Compliant</span>
                                    ) : (
                                      <span className="text-red-600">Over Limit</span>
                                    )}
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      </div>
    </Layout>
  );
}